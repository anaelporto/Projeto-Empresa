/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unesp.rc.Entity;

/**
 *
 * @author anael
 */

import javax.persistence.*;
 
@Entity
@Table(name = "pFisica")
public class pFisica {
     
    @Column(name = "")
    private Long CPF;
    
    @Column(name = "nome", nullable = false, length = 40)
    private String nome;
    
    @Column(nullable = false, unique = true, length = 30)
    private String login;
     
    @Column(nullable = false, length = 30)
    private String senha;

    
     
    // getters and setters are not shown   
}